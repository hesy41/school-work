/* data structure: homework 5 main.cpp
   author: Siyi He
   create on 2021-11-18
*/

#include <iostream>
#include "pqtype.h"
//#include "pqtype.cpp"
/* #include "heap.cpp"
#include "heap.h" */
using namespace std;

//template<class ItemType> 
int main(){
    
    PQType pq(4);

    ItemType a, b, c, d;

    a.Initialize(9);
    b.Initialize(3);
    c.Initialize(40);
    d.Initialize(1);

    pq.Enqueue(a);
    pq.Enqueue(b); 
    pq.Enqueue(c);
    pq.Enqueue(d);  

    if (pq.IsFull())
        cout<< "is full" << endl;
    else
        cout<< "not full" << endl;

    return 0;
}