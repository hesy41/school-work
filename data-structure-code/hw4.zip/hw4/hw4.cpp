/*  homework4_Binary_Search_Tree_exerscise: BST_ex.cpp
    author: Siyi He
    created 2020-11-1
    issue: I have tried to put countNode in the member function, but there is an error says "TreeType::countNode" 
           type does not match, why??
    bug: (line 211) : qualified name is not allowed
*/

#include <iostream>
#include <fstream>
#include "hw4.h"
using namespace std;

void copyTree(TreeNode*&, const TreeNode*);
void killTree(TreeNode*& node);
int countNode(TreeNode* root);
void retrieve(TreeNode* root, ItemType item, bool& found);
void printTree(TreeNode* tree, std::ofstream& outFile);
void insertNode(TreeNode*& tree, ItemType item);
void deletetion(TreeNode*& tree, ItemType item);
void deleteNode(TreeNode*& tree);
void GetPredecessor(TreeNode* tree, ItemType& data);

struct TreeNode
{
    ItemType info;
    TreeNode* left;
    TreeNode* right;
};

TreeType::TreeType()
{
    root = new TreeNode;
    root = NULL;
}

TreeType::TreeType(const TreeType& originalTree)
{
    copyTree(root, originalTree.root);
}

void copyTree(TreeNode*& copyRoot, const TreeNode* originalRoot)
{
    if (originalRoot==NULL)
        copyRoot = NULL;
    else{
        copyRoot = new TreeNode;
        copyRoot->info = originalRoot->info;
        copyTree(copyRoot->left, originalRoot->left);
        copyTree(copyRoot->right, originalRoot->right);
    }
}

TreeType::~TreeType()
{
    killTree(root);
}

void killTree(TreeNode*& root)
{
    if (root != NULL)
    {
        killTree(root->left);
        killTree(root->right);
        delete root;
    }
}

bool TreeType::IsEmpty() const 
{
    return (root == NULL);
}

bool TreeType::IsFull() const 
{
    TreeNode* node;
    //test if there is more room on the free stone
    //if there is, then this tree is not full
    try 
    {
        node = new TreeNode;
        delete node;
        return false;
    }
    catch (std::bad_alloc exception)
    {
        //if there is no room, then system automatically throw bad_alloc message
        return true;
    }
}

int TreeType::GetLength() const 
{
    return countNode(root);
}

int countNode(TreeNode* tree)
{
    if (tree != NULL)
        return countNode(tree->right)+countNode(tree->left)+1;
    else
        return 0;
}

ItemType TreeType::GetItem(ItemType item, bool& found)
{
    retrieve(root, item, found);
    return item;
}

void retrieve(TreeNode* tree, ItemType item, bool& found)
{
    if (tree=NULL)
        found=false;
    else
    {
        if(item < tree->info) // item is in the left part of the tree
            retrieve(tree->left, item, found);
        else if (item > tree->info) // item is in the left part of the tree
            retrieve(tree->right, item, found);
        else // item is found
            found =true;
    }
}

void TreeType::Print(std::ofstream& outFile) const
{
  printTree(root, outFile);
}

void PrintTree(TreeNode* tree, std::ofstream& outFile)
{
  if (tree != NULL)
  {
    PrintTree(tree->left, outFile);  
    outFile << tree->info;
    PrintTree(tree->right, outFile); 
}

/*problem 5*/
int countNonleaf(TreeNode* root);
void storeNode(ItemType* array, int count);

ItemType* TreeType::GetNodes()
{
    ItemType* array;
    array = new ItemType[countNonleaf(root)];

    storeNode(array, countNonleaf(root)-1, root);
}

void storeNode(ItemType* array, int count, TreeNode* root)
{
    if (count == 0)
        return;
    if (root != Null && (root->left !=NULL || root->right != NULL))
    {
        array[count]=root->info;
        storeNode(array, count-1, root->left);
        streoNode(array, count-1, root->right);
    }
}

int countNonleaf(TreeNode* root)
{
    if (root == NULL || (root->left == NULL && root->right == NULL))
        return 0;
 
    return 1 + countNonleaf(root->left) +
               countNonleaf(root->right);
}

/*problem 4*/
void TreeType::deleteSmallest(TreeNode*& root)
{
    //the smallest item must be the leaf on the very left
    if (isEmpty())
        return; //there is no smallest leaf in an empty tree

    if (root->left != NULL)
    {
        deleteSmallest(root->left);
    }
    else 
        deleteItem(root->info); //use deleteItem to delete
}

/*problem 3*/
bool TreeType::PrintAncestors(TreeNode *root, ItemType target) const
{
  if (root == NULL)
     return false;//no tartget can be found in a empty tree
 
  if (root->data == target)
     return true;
 
  if ( printAncestors(root->left, target) || printAncestors(root->right, target) )
  {
    cout << root->data << " ";
    return true;
  }
 
  return false;
}

/*problem 2*/
bool isBSTUtil(TreeNode* node); 

bool TreeType::IsBST() const
{ 
    return isBSTUtil(root); 
} 
bool isBSTUtil(TreeNode* node)
{ 
    if (node==NULL) 
        return true; 
            
    if ((node->right)->info < node->info || (node->left)->info > node->info) 
        return false; 

    return isBSTUtil(node->left) && isBSTUtil(node->right);
}

/*bonus*/
void storeViolators(ItemType* array, int& count, TreeNode* root);

ItemType TreeType::FindViolators()
{
    int count = 0;
    ItemType* array;
    array = new ItemType[root.GetLength()]; 

    storeViolators(array, count, root);
}

void storeViolators(ItemType* array, in& count, TreeNode* root)
{
    if (root == NULL)
        return;

    if ((root->right)->info < root->info || (root->left)->info > root->info)
    {
        array[count]=root->info;
        storeNode(array, count+1, root->left);
        streoNode(array, count+1, root->right);
    }
    
}
/*else*/
void TreeType::MakeEmpty()
{
    killTree(root);
    root = NULL;
}

void TreeType::PutItem(ItemType item)
{
    insertNode(root, item);
}

void insert(TreeNode*& tree, ItemType item)
{
    if (tree == NULL)
    {
        tree = new TreeNode;
        tree->info = item;
        tree->left = NULL;
        tree->right = NULL;
    }
    else if (tree->info < item)
        insertNode(tree->left, item);
    else
        insertNode(tree->right, item);
}

void TreeType::DeleteItem(ItemType item)
{
    deletetion(root, item);
}

void deletetion(TreeNode*& tree, ItemType item)
{
    if (item < tree->info)
        deletetion(tree->left, item);   
    else if (item > tree->info)
        deletetion(tree->right, item);  
    else
        deleteNode(tree);  
}

void deleteNode(TreeNode*& tree)
{
    ItemType data;
    TreeNode* tempPtr;

    tempPtr = tree;
    if (tree->left == NULL)
    {
        tree = tree->right;
        delete tempPtr;
    }
    else if (tree->right == NULL)
    {
        tree = tree->left;
        delete tempPtr;
    }
    else
    {
        GetPredecessor(tree->left, data);
        tree->info = data;
        deletetion(tree->left, data);
    }
}

void GetPredecessor(TreeNode* tree, ItemType& data)
{
  while (tree->right != NULL)
    tree = tree->right;
  data = tree->info;
} 

