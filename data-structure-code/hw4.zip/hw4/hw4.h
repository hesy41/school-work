/*  homework4_Binary_Search_Tree_exerscise: BST_ex.h
    author: Siyi He
    created 2020-11-1
*/

#include <iostream>
using namespace std;

#ifndef HW4_H
#define HW4_H

typedef char ItemType;
struct TreeNode;

class TreeType
{
    public:
        TreeType();
        ~TreeType();
        TreeType(const TreeType& originalTree);
        //void MakeEmpty();
        bool IsEmpty() const;
        bool IsFull() const;
        int GetLength() const;
        ItemType GetItem(ItemType item, bool& found);
        //void PutItem(ItemType item);
        //void DeleteItem(ItemType item);
        void Print(std::ofstream& outFile) const;
        bool IsBST() const;
        void PrintAncestors(TreeNode*root, ItemType target) const;
        void deleteSmallest(TreeNode*& root);
        ItemType* GetNodes();
        ItemType* FindViolators();
        
    private:
        TreeNode* root;
};

#endif